jQuery(function () {
    jQuery('.hs-equalheight').matchHeight({
        byRow: true
    });
});