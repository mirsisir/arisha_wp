<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Buttons;
?>
<div id="bookly-payment-attach-modal" class="modal fade" tabindex=-1 role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="modal-title h2"><?php _e( 'Attach payment', 'bookly' ) ?></div>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label><?php _e( 'Enter payment ID', 'bookly' ) ?></label>
                    <input class="form-control bookly-js-attach-payment-id" type="text" ng-model="attach.payment_id"/>
                </div>
            </div>
            <div class="modal-footer">
                <div ng-hide=loading>
                    <?php Buttons::renderSubmit( 'bookly-attach-payment-apply', null, __( 'Apply', 'bookly' ), array( 'data-dismiss' => 'modal', 'data-toggle' => 'modal', 'href' => '#bookly-payment-details-modal', 'data-payment_id' => '{{attach.payment_id}}', 'data-payment_bind' => true ) ) ?>
                    <?php Buttons::renderCustom( null, 'btn-lg btn-default', __( 'Cancel', 'bookly' ), array( 'data-dismiss' => 'modal' ) ) ?>
                </div>
            </div>
        </div>
    </div>
</div>