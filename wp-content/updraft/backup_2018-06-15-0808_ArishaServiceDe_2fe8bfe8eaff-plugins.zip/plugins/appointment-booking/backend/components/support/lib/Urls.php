<?php
namespace Bookly\Backend\Components\Support\Lib;

/**
 * Class Urls
 * @package Bookly\Backend\Components\Support\Lib
 */
abstract class Urls
{
    const BOOKLY_CODECANYON_PAGE = 'https://codecanyon.net/item/bookly-booking-plugin-responsive-appointment-booking-and-scheduling/7226091?ref=ladela';
}