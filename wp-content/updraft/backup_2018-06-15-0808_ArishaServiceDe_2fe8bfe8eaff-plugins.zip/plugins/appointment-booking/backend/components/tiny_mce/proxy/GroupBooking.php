<?php
namespace Bookly\Backend\Components\TinyMce\Proxy;

use Bookly\Lib;

/**
 * Class GroupBooking
 * @package Bookly\Backend\Components\TinyMce\Proxy\Proxy
 *
 * @method static void renderStaffCabinetSettings() Render settings in Staff Cabinet shortcode.
 */
abstract class GroupBooking extends Lib\Base\Proxy
{

}